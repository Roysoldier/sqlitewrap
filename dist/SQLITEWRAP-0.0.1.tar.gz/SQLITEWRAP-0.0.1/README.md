# Sqlite Wrapper

This is a simple wrapper class for sqlite